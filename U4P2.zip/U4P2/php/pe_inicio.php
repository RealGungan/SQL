<!doctype html>
<html lang="es">

<head>
    <title> </title>
    <meta charset="utf-8" />
    <meta name="author" content="tu nombre" />
    <link href=".css" rel="stylesheet" type="text/css" />
</head>

<body>
    <h1>Portal de compras web</h1>
    <div id="container">
        <ul>
            <li><a href="pe_login.php">Login cliente</a></li>
            <br />
            <li><a href="pe_altaped.php">Comprar productos</a></li>
            <br />
            <li><a href="pe_consped.php">Consultar información pedido</a></li>
            <br />
            <li><a href="pe_consprodstock.php">Consultar stock</a></li>
            <br />
            <li><a href="pe_constock.php">Consultar stock línea</a></li>
            <br />
            <li><a href="pe_topprod.php">Consultar compras</a></li>
            <br />
            <li><a href="pe_conspago.php">Consultar gastos</a></li>
        </ul>
    </div>
</body>

</html>