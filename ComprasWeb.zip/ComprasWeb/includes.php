<?php
include 'Client/client.php';
include 'connection/connection.php';
include 'DB/db.php';
include 'Print/print.php';
include 'Purchase/purchase.php';
include 'TestInput/testinput.php';
include 'Warehouse/warehouse.php';
